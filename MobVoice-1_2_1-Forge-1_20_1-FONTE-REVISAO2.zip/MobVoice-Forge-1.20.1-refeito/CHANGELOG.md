# Changelog

## 1.1.0 — Expansão do gravador de criaturas

- Adicionado item Gravador de Voz com modelo, textura, tooltip, receita e entrada no criativo.
- Adicionada tela de estúdio para escolher categoria, gravar, salvar, ouvir e excluir.
- Adicionados sons personalizados de ambiente, dano, morte e passos.
- Arquivos WAV organizados por identificador de entidade e por adulto/filhote.
- Adicionada substituição local dos sons do jogo quando existe gravação correspondente.
- Adicionado limite de duração configurável e fallback de filhote para gravação adulta.
- Mantido o sistema anterior de conversa, memória, personalidade e afinidade.


## 1.1.1 - Expansão do estúdio
- Adicionadas categorias de gravação Ataque e Alerta.
- Ampliados os traços de personalidade, peculiaridades e objetivos dos perfis gerados para criaturas.
- Atualizada a documentação em português e inglês.


## 1.2.0 - mecânicas sociais adicionais
- Villagers podem localizar a vila mais próxima em troca de 3 esmeraldas.
- Piglins podem localizar o bastião mais próximo em troca de 5 lingotes de ouro.
- Insultos e desafios reconhecidos provocam criaturas de combate e reduzem afinidade.
- A IA recebe a categoria do item na mão do jogador (espada, arco/besta, machado ou outro) para variar a reação.
- Comunicação por voz continua no modo segurar V para falar e soltar para enviar.


## 1.2.1 - revisão completa
Correções de compilação:
- `ServerLevel.findNearestMapStructure` devolve `BlockPos` no 1.20.1 (o código usava `.getFirst()`).
- `StructureTags.BASTION_REMNANT` não existe; a busca de bastiões agora usa o registro de estruturas, como o `/locate`.
- `Inventory.removeItem(Item, int)` não existe; o pagamento usa `clearOrCountMatchingItems` e sincroniza o inventário.

Correções de comportamento:
- Servidor: textos/respostas longos não quebram mais os pacotes (`writeUtf`); respostas da IA têm limite de tamanho.
- Servidor: limite de requisições simultâneas e anti-spam por jogador também em `talk()`; feedback quando o mob já está "pensando".
- Servidor: nome dado com name tag deixa de ser sobrescrito; a memória é apagada só se a morte não for cancelada.
- Servidor: provocar um amigo não afirma mais que ele ficou agressivo quando o ataque foi bloqueado.
- Servidor: valores fora da faixa em `mobvoice.json` são ajustados ao limite, e chaves `null` não causam erro; contador de requisições não vaza mais.
- Cliente: tela do gravador não abre mais a partir da thread do servidor integrado (e não dispara duas vezes).
- Cliente: falha no microfone não é mais repetida a cada tick; gravação por V respeita `maxRecordingSeconds`; microfone é liberado ao sair do mundo ou fechar a tela.
- Cliente: atenuação/pan agora usam a posição do ouvinte (antes o volume não caía com a distância); respeita volumes do jogo; reprodução fora da thread principal; limite de clipes simultâneos.
- Cliente: erro de transcrição não exibe mais o corpo da resposta da API (podia ecoar parte da chave).
- Scripts: verificação exata de JDK 17 e Gradle 8.x; `.bat` com quebras de linha CRLF.
