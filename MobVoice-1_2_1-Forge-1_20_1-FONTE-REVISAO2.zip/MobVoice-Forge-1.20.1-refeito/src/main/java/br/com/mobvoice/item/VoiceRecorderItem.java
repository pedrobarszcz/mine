package br.com.mobvoice.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public class VoiceRecorderItem extends Item {
    public VoiceRecorderItem(Properties properties) { super(properties); }

    @Override
    public void appendHoverText(net.minecraft.world.item.ItemStack stack, Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.mobvoice.voice_recorder.line1"));
        tooltip.add(Component.translatable("tooltip.mobvoice.voice_recorder.line2"));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
