package br.com.mobvoice;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

import java.util.Random;

/** Gera nome, personalidade e historia unicos a partir do UUID do mob. */
public final class MobProfileFactory {
    private static final String[] NAMES = {
            "Bartolomeu", "Dona Cleusa", "Zeca", "Pipoca", "Mortadela", "Genoveva", "Tião", "Quitéria",
            "Rufino", "Violeta", "Bento", "Neide", "Jurandir", "Fofura", "Osvaldo", "Marilu", "Cacá", "Eustáquio"
    };
    private static final String[] TRAITS = {
            "tímido", "fanfarrão", "melancólico", "otimista incurável", "desconfiado", "curioso demais",
            "preguiçoso", "dramático", "sarcástico", "gentil", "mandão", "sonhador", "medroso", "ranzinza"
    };
    private static final String[] QUIRKS = {
            "fala de si mesmo na terceira pessoa", "adora dar conselhos que ninguém pediu",
            "tem medo irracional de abóboras", "coleciona gravetos e fala deles com orgulho",
            "faz piadas ruins e ri sozinho", "acha que é o herói de uma grande lenda",
            "é obcecado por previsão do tempo", "sempre pergunta se o jogador já comeu",
            "tem uma rivalidade antiga com galinhas", "fala como se estivesse narrando uma aventura",
            "fica animado quando vê flores", "acredita que diamantes dão sorte",
            "gosta de observar o nascer do sol", "tem pavor de cavernas escuras"
    };
    private static final String[] PLACES = {
            "numa caverna úmida", "à beira de um lago", "numa planície ventosa",
            "debaixo de uma árvore enorme", "perto de uma vila abandonada", "numa montanha nevada"
    };
    private static final String[] EVENTS = {
            "perdeu a família numa noite de tempestade", "foi expulso do bando por ser diferente",
            "sobreviveu a uma explosão misteriosa", "viu um dragão cruzar o céu e nunca esqueceu",
            "foi criado por um aldeão gentil que desapareceu", "encontrou um mapa antigo que não sabe ler"
    };
    private static final String[] DREAMS = {
            "quer ver o mar", "sonha em ter um amigo de verdade", "quer provar um bolo",
            "quer descobrir quem é o dono do mundo", "quer ficar rico em esmeraldas", "só quer paz e silêncio", "quer construir uma casa própria", "sonha em conhecer uma vila distante",
            "quer aprender a pescar", "deseja encontrar um tesouro perdido"
    };

    private MobProfileFactory() {}

    public static MobData create(Mob mob) {
        long seed = mob.getUUID().getMostSignificantBits() ^ mob.getUUID().getLeastSignificantBits();
        Random r = new Random(seed);
        MobData d = new MobData();
        d.type = EntityType.getKey(mob.getType()).getPath();
        d.name = NAMES[r.nextInt(NAMES.length)];
        String t1 = TRAITS[r.nextInt(TRAITS.length)];
        String t2 = TRAITS[r.nextInt(TRAITS.length)];
        d.personality = t1 + " e " + t2 + "; " + QUIRKS[r.nextInt(QUIRKS.length)];
        d.backstory = "Nasceu " + PLACES[r.nextInt(PLACES.length)] + ", " + EVENTS[r.nextInt(EVENTS.length)]
                + ". Hoje " + DREAMS[r.nextInt(DREAMS.length)] + ".";
        return d;
    }
}
