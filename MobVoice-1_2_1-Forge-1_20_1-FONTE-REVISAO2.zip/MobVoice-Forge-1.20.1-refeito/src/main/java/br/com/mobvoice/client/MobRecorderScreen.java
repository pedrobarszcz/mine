package br.com.mobvoice.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/** Interface para gravar e administrar a voz personalizada de uma criatura. */
public class MobRecorderScreen extends Screen {
    private final ResourceLocation entityType;
    private final String entityName;
    private final boolean baby;
    private final VoiceRecorder recorder = new VoiceRecorder();
    private MobSoundLibrary.SoundKind selected = MobSoundLibrary.SoundKind.AMBIENT;
    private String status = "Escolha o som e pressione Gravar.";

    public MobRecorderScreen(ResourceLocation entityType, String entityName, boolean baby) {
        super(Component.literal("Gravador de voz - " + entityName));
        this.entityType = entityType;
        this.entityName = entityName;
        this.baby = baby;
    }

    @Override
    protected void init() {
        int center = width / 2;
        int top = height / 2 - 72;
        int buttonWidth = 48;
        int gap = 2;
        MobSoundLibrary.SoundKind[] kinds = MobSoundLibrary.SoundKind.values();
        for (int i = 0; i < kinds.length; i++) {
            MobSoundLibrary.SoundKind kind = kinds[i];
            addRenderableWidget(Button.builder(Component.literal(kind.label), b -> {
                if (recorder.isRecording()) return;
                selected = kind;
                status = "Som selecionado: " + kind.label;
            }).bounds(center - 150 + i * (buttonWidth + gap), top, buttonWidth, 20).build());
        }

        addRenderableWidget(Button.builder(Component.literal("Gravar"), b -> startRecording())
                .bounds(center - 140, top + 34, 88, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Parar e salvar"), b -> stopAndSave())
                .bounds(center - 46, top + 34, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Ouvir prévia"), b -> preview())
                .bounds(center + 60, top + 34, 88, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Excluir"), b -> delete())
                .bounds(center - 94, top + 62, 88, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Fechar"), b -> onClose())
                .bounds(center + 6, top + 62, 88, 20).build());
    }

    private void startRecording() {
        if (recorder.isRecording()) return;
        if (recorder.start()) status = "Gravando " + selected.label + "... fale agora.";
        else status = "Não foi possível abrir o microfone. Confira a permissão do Windows.";
    }

    private void stopAndSave() {
        if (!recorder.isRecording()) { status = "Nenhuma gravação em andamento."; return; }
        byte[] pcm = recorder.stop();
        try {
            MobSoundLibrary.save(entityType, baby, selected, pcm);
            status = "Gravação salva para " + entityName + " (" + selected.label + ").";
        } catch (Exception ex) {
            status = "Não foi possível salvar: " + ex.getMessage();
        }
    }

    private void preview() {
        try {
            MobSoundLibrary.preview(entityType, baby, selected);
            status = "Reproduzindo prévia de " + selected.label + ".";
        } catch (Exception ex) { status = ex.getMessage(); }
    }

    private void delete() {
        try {
            boolean deleted = MobSoundLibrary.delete(entityType, baby, selected);
            status = deleted ? "Gravação excluída." : "Não havia gravação salva.";
        } catch (Exception ex) { status = "Falha ao excluir: " + ex.getMessage(); }
    }

    @Override
    public void tick() {
        super.tick();
        if (recorder.isRecording() && recorder.elapsedMillis() > br.com.mobvoice.AiConfig.get().maxRecordingSeconds * 1000L) stopAndSave();
    }

    @Override
    public void removed() {
        // Chamado sempre que a tela sai (ESC, desconexão, outra tela): nunca deixa o microfone aberto.
        if (recorder.isRecording()) recorder.stop();
        super.removed();
    }

    @Override
    public void onClose() {
        if (recorder.isRecording()) stopAndSave();
        if (minecraft != null) minecraft.setScreen(null);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        String age = baby ? "Filhote" : "Adulto";
        graphics.drawCenteredString(font, title, width / 2, height / 2 - 102, 0xFFFFFF);
        graphics.drawCenteredString(font, entityName + " • " + age, width / 2, height / 2 - 88, 0xAAAAAA);
        graphics.drawCenteredString(font, status, width / 2, height / 2 + 42, 0xE6D58A);
        graphics.drawCenteredString(font, "Cada gravação é salva localmente neste computador.", width / 2, height / 2 + 58, 0x888888);
    }
}
