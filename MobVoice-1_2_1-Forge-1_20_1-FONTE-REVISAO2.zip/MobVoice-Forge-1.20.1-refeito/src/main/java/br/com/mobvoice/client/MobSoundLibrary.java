package br.com.mobvoice.client;

import br.com.mobvoice.MobVoice;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.fml.loading.FMLPaths;

import javax.sound.sampled.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Biblioteca local de vozes. Os arquivos ficam em config/mobvoice/recordings. */
public final class MobSoundLibrary {
    public enum SoundKind {
        AMBIENT("ambient", "Amb."), HURT("hurt", "Dano"), DEATH("death", "Morte"),
        STEP("step", "Passos"), ATTACK("attack", "Ataque"), ANGRY("angry", "Alerta");
        public final String id;
        public final String label;
        SoundKind(String id, String label) { this.id = id; this.label = label; }
    }

    private static final Set<Clip> ACTIVE = ConcurrentHashMap.newKeySet();
    private static final int MAX_ACTIVE_CLIPS = 16;
    private static final double MAX_AUDIBLE_DISTANCE = 32.0;
    private static final ExecutorService PLAYER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "MobVoice-AudioPlayer");
        t.setDaemon(true);
        return t;
    });

    private MobSoundLibrary() { }

    public static Path directory() {
        return FMLPaths.CONFIGDIR.get().resolve("mobvoice").resolve("recordings");
    }

    public static Path file(ResourceLocation entityType, boolean baby, SoundKind kind) {
        String namespace = safe(entityType.getNamespace());
        String path = safe(entityType.getPath());
        return directory().resolve(namespace + "_" + path).resolve(baby ? "baby" : "adult").resolve(kind.id + ".wav");
    }

    public static boolean exists(ResourceLocation type, boolean baby, SoundKind kind) {
        return Files.isRegularFile(file(type, baby, kind));
    }

    public static void save(ResourceLocation type, boolean baby, SoundKind kind, byte[] pcm) throws IOException {
        if (pcm == null || pcm.length < 8000) throw new IOException("Gravação muito curta. Grave pelo menos 0,25 segundo.");
        Path target = file(type, baby, kind);
        Files.createDirectories(target.getParent());
        Files.write(target, toWav(pcm));
    }

    public static boolean delete(ResourceLocation type, boolean baby, SoundKind kind) throws IOException {
        return Files.deleteIfExists(file(type, baby, kind));
    }

    public static void preview(ResourceLocation type, boolean baby, SoundKind kind) throws Exception {
        Path path = file(type, baby, kind);
        if (!Files.isRegularFile(path)) throw new IOException("Ainda não existe gravação para este som.");
        playFile(path, 1.0f, 0.0f);
    }

    /**
     * Intercepta um som vanilla e reproduz o WAV personalizado no cliente.
     * Retorna true quando o som original deve ser cancelado.
     */
    public static boolean replace(Entity entity, SoundKind kind, float volume, double soundX, double soundY, double soundZ) {
        ResourceLocation type = net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType());
        if (type == null) return false;
        boolean baby = entity instanceof AgeableMob ageable && ageable.isBaby();
        Path custom = file(type, baby, kind);
        if (!Files.isRegularFile(custom) && baby) custom = file(type, false, kind);
        if (!Files.isRegularFile(custom)) return false;
        if (ACTIVE.size() >= MAX_ACTIVE_CLIPS) return false; // muitos sons simultâneos: deixa o som original tocar

        // A atenuação e o pan dependem de onde o OUVINTE (câmera) está, não do mob.
        Minecraft mc = Minecraft.getInstance();
        Vec3 listener = mc.gameRenderer.getMainCamera().getPosition();
        double dx = soundX - listener.x;
        double dy = soundY - listener.y;
        double dz = soundZ - listener.z;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (distance > MAX_AUDIBLE_DISTANCE) return true; // o som vanilla também seria inaudível
        float attenuation = (float) (1.0 / (1.0 + distance * 0.12));

        float pan = 0.0f;
        if (distance > 0.5) {
            double yaw = Math.toRadians(mc.gameRenderer.getMainCamera().getYRot());
            // vetor "direita" do jogador no plano XZ
            double rightX = -Math.cos(yaw), rightZ = -Math.sin(yaw);
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            if (horizontal > 0.001) pan = (float) ((dx * rightX + dz * rightZ) / horizontal);
        }

        final Path chosen = custom;
        final float finalVolume = Math.max(0.05f, Math.min(1.0f, volume * attenuation));
        final float finalPan = pan;
        // Leitura de disco e abertura do Clip fora da thread principal do jogo (evita engasgos).
        PLAYER.execute(() -> {
            try {
                playFile(chosen, finalVolume, finalPan);
            } catch (Exception ex) {
                MobVoice.LOGGER.warn("Falha ao reproduzir gravação: {}", ex.getMessage());
            }
        });
        return true;
    }

    private static void playFile(Path path, float volume, float pan) throws Exception {
        try (var input = AudioSystem.getAudioInputStream(path.toFile())) {
            Clip clip = AudioSystem.getClip();
            try {
                clip.open(input);
                ACTIVE.add(clip);
                if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                    float db = volume <= 0.001f ? gain.getMinimum() : (float) (20.0 * Math.log10(volume));
                    gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), db)));
                }
                if (clip.isControlSupported(FloatControl.Type.PAN)) {
                    ((FloatControl) clip.getControl(FloatControl.Type.PAN)).setValue(Math.max(-1f, Math.min(1f, pan)));
                }
                clip.addLineListener(event -> {
                    if (event.getType() == LineEvent.Type.STOP) {
                        ACTIVE.remove(clip);
                        clip.close();
                    }
                });
                clip.start();
            } catch (Exception ex) {
                ACTIVE.remove(clip);
                clip.close(); // não vaza a linha de áudio se algo falhar após o open()
                throw ex;
            }
        }
    }

    private static byte[] toWav(byte[] pcm) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(pcm.length + 44);
        out.write("RIFF".getBytes(java.nio.charset.StandardCharsets.US_ASCII));
        le32(out, 36 + pcm.length);
        out.write("WAVEfmt ".getBytes(java.nio.charset.StandardCharsets.US_ASCII));
        le32(out, 16); le16(out, 1); le16(out, 1); le32(out, 16000); le32(out, 32000); le16(out, 2); le16(out, 16);
        out.write("data".getBytes(java.nio.charset.StandardCharsets.US_ASCII));
        le32(out, pcm.length); out.write(pcm);
        return out.toByteArray();
    }

    private static void le32(ByteArrayOutputStream out, int value) { out.write(value); out.write(value >>> 8); out.write(value >>> 16); out.write(value >>> 24); }
    private static void le16(ByteArrayOutputStream out, int value) { out.write(value); out.write(value >>> 8); }
    private static String safe(String value) { return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "_"); }
}
