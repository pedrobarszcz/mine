package br.com.mobvoice;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraftforge.fml.loading.FMLPaths;

import java.nio.file.Files;
import java.nio.file.Path;

/** Configuração local do MobVoice. O arquivo é criado em .minecraft/config/mobvoice.json. */
public final class AiConfig {
    public String apiKey = "COLE_SUA_CHAVE_AQUI";
    public String model = "claude-haiku-4-5-20251001";
    public String endpoint = "https://api.anthropic.com/v1/messages";
    public int maxTokens = 300;
    public int historyLimit = 24;
    public boolean autonomousBrain = true;
    public boolean replaceRecordedSounds = true;
    public int maxRecordingSeconds = 15;
    public int thinkIntervalSeconds = 45;
    public int maxConcurrentRequests = 3;

    public String sttEndpoint = "https://api.openai.com/v1/audio/transcriptions";
    public String sttApiKey = "COLE_SUA_CHAVE_DE_VOZ_AQUI";
    public String sttModel = "whisper-1";
    public String sttLanguage = "pt";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static volatile AiConfig instance;

    private AiConfig() { }

    public static AiConfig get() {
        AiConfig result = instance;
        if (result != null) return result;
        synchronized (AiConfig.class) {
            if (instance == null) instance = load();
            return instance;
        }
    }

    private static AiConfig load() {
        Path file = FMLPaths.CONFIGDIR.get().resolve("mobvoice.json");
        AiConfig defaults = new AiConfig();
        try {
            Files.createDirectories(file.getParent());
            if (!Files.exists(file)) {
                Files.writeString(file, GSON.toJson(defaults));
                return defaults;
            }
            AiConfig loaded = GSON.fromJson(Files.readString(file), AiConfig.class);
            if (loaded == null) return defaults;
            // Protege configurações parcialmente preenchidas ou editadas incorretamente.
            if (loaded.apiKey == null) loaded.apiKey = defaults.apiKey;
            if (loaded.sttApiKey == null) loaded.sttApiKey = defaults.sttApiKey;
            if (blank(loaded.model)) loaded.model = defaults.model;
            if (blank(loaded.endpoint)) loaded.endpoint = defaults.endpoint;
            if (blank(loaded.sttEndpoint)) loaded.sttEndpoint = defaults.sttEndpoint;
            if (blank(loaded.sttModel)) loaded.sttModel = defaults.sttModel;
            if (blank(loaded.sttLanguage)) loaded.sttLanguage = defaults.sttLanguage;
            loaded.maxTokens = clamp(loaded.maxTokens, 64, 2048, defaults.maxTokens);
            loaded.historyLimit = clamp(loaded.historyLimit, 4, 100, defaults.historyLimit);
            loaded.maxConcurrentRequests = clamp(loaded.maxConcurrentRequests, 1, 8, defaults.maxConcurrentRequests);
            loaded.thinkIntervalSeconds = clamp(loaded.thinkIntervalSeconds, 15, 3600, defaults.thinkIntervalSeconds);
            loaded.maxRecordingSeconds = clamp(loaded.maxRecordingSeconds, 3, 60, defaults.maxRecordingSeconds);
            return loaded;
        } catch (Exception ex) {
            MobVoice.LOGGER.error("Não foi possível ler config/mobvoice.json: {}", ex.getMessage());
            return defaults;
        }
    }

    private static boolean blank(String value) { return value == null || value.isBlank(); }
    private static int clamp(int value, int min, int max, int fallback) {
        // Valores fora da faixa são ajustados ao limite mais próximo (ex.: 5000 tokens -> 2048).
        return Math.max(min, Math.min(max, value));
    }
}
