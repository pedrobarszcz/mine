package br.com.mobvoice.client;

import br.com.mobvoice.AiConfig;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/** Voz -> texto via API compativel com a da OpenAI (Whisper). Java puro, sem bibliotecas nativas. */
public final class SpeechToText {
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    private SpeechToText() {}

    public static String transcribe(byte[] pcm) {
        try {
            AiConfig cfg = AiConfig.get();
            if (cfg.sttApiKey == null || cfg.sttApiKey.isBlank() || cfg.sttApiKey.startsWith("COLE_")) {
                throw new IllegalStateException("Configure sttApiKey em config/mobvoice.json");
            }
            String boundary = "----MobVoice" + System.nanoTime();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            field(out, boundary, "model", cfg.sttModel);
            field(out, boundary, "language", cfg.sttLanguage);
            field(out, boundary, "response_format", "json");
            out.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\n"
                    + "Content-Type: audio/wav\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            out.write(wav(pcm));
            out.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));

            HttpRequest req = HttpRequest.newBuilder(URI.create(cfg.sttEndpoint))
                    .timeout(Duration.ofSeconds(30))
                    .header("Authorization", "Bearer " + cfg.sttApiKey)
                    .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                    .POST(HttpRequest.BodyPublishers.ofByteArray(out.toByteArray()))
                    .build();
            HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            // Não repete o corpo da resposta: erros de autenticação podem ecoar parte da chave no chat.
            if (resp.statusCode() != 200) throw new RuntimeException("serviço de transcrição respondeu HTTP " + resp.statusCode()
                    + ". Confira sttApiKey, sttEndpoint e sttModel em config/mobvoice.json.");
            JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();
            return json.has("text") ? json.get("text").getAsString().trim() : "";
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    private static void field(ByteArrayOutputStream out, String boundary, String name, String value) throws Exception {
        out.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n"
                + value + "\r\n").getBytes(StandardCharsets.UTF_8));
    }

    /** PCM 16 kHz, 16 bits, mono -> arquivo WAV. */
    private static byte[] wav(byte[] pcm) {
        int rate = 16000, channels = 1, bits = 16;
        int byteRate = rate * channels * bits / 8;
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.writeBytes("RIFF".getBytes(StandardCharsets.US_ASCII));
        le32(o, 36 + pcm.length);
        o.writeBytes("WAVEfmt ".getBytes(StandardCharsets.US_ASCII));
        le32(o, 16); le16(o, 1); le16(o, channels); le32(o, rate); le32(o, byteRate);
        le16(o, channels * bits / 8); le16(o, bits);
        o.writeBytes("data".getBytes(StandardCharsets.US_ASCII));
        le32(o, pcm.length);
        o.writeBytes(pcm);
        return o.toByteArray();
    }

    private static void le32(ByteArrayOutputStream o, int v) {
        o.write(v & 0xff); o.write((v >> 8) & 0xff); o.write((v >> 16) & 0xff); o.write((v >> 24) & 0xff);
    }

    private static void le16(ByteArrayOutputStream o, int v) {
        o.write(v & 0xff); o.write((v >> 8) & 0xff);
    }
}
