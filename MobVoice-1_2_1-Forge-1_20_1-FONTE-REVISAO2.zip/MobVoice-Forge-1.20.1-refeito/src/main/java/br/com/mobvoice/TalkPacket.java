package br.com.mobvoice;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Cliente -> servidor: "o jogador disse X para o mob de id Y". */
public class TalkPacket {
    public final int entityId;
    public final String text;

    public TalkPacket(int entityId, String text) {
        this.entityId = entityId;
        this.text = Net.clip(text, 256); // writeUtf(256) falharia com textos longos (voz/ /falar)
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(entityId);
        buf.writeUtf(text, 256);
    }

    public static TalkPacket decode(FriendlyByteBuf buf) {
        return new TalkPacket(buf.readInt(), buf.readUtf(256));
    }

    public void handle(Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> {
            ServerPlayer p = ctx.getSender();
            if (p == null || p.getServer() == null) return;
            Entity e = p.serverLevel().getEntity(entityId);
            if (e instanceof Mob mob && mob.isAlive() && mob.distanceToSqr(p) <= 144) {
                MobBrain.talk(p.getServer(), p, mob, text.trim());
            }
        });
        ctx.setPacketHandled(true);
    }
}
