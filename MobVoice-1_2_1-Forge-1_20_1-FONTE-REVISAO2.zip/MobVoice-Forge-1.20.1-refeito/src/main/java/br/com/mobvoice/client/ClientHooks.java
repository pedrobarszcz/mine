package br.com.mobvoice.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class ClientHooks {
    private ClientHooks() {}

    public static void onReply(int entityId, String text, int affinity, String note) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        Entity e = mc.level.getEntity(entityId);
        String name = e != null ? e.getName().getString() : "Mob";

        mc.gui.getChat().addMessage(Component.literal("<" + name + "> ").withStyle(ChatFormatting.YELLOW)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE)));

        String bar = "Afinidade com " + name + ": " + affinity;
        if (note != null && !note.isBlank()) bar += "  |  " + note;
        mc.player.displayClientMessage(Component.literal(bar), true);
    }
}
