package br.com.mobvoice;

import net.minecraft.world.item.Item;
import br.com.mobvoice.item.VoiceRecorderItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Itens registrados pelo MobVoice. */
@Mod.EventBusSubscriber(modid = MobVoice.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MobVoice.MOD_ID);

    public static final RegistryObject<Item> VOICE_RECORDER = ITEMS.register("voice_recorder",
            () -> new VoiceRecorderItem(new Item.Properties().stacksTo(1)));

    private ModItems() { }

    public static void register(IEventBus bus) { ITEMS.register(bus); }

    @SubscribeEvent
    public static void addCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey().equals(net.minecraft.world.item.CreativeModeTabs.TOOLS_AND_UTILITIES)) {
            event.accept(VOICE_RECORDER);
        }
    }
}
