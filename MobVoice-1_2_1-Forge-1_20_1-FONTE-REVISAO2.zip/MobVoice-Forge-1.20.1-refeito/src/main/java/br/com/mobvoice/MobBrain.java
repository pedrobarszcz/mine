package br.com.mobvoice;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.tags.StructureTags;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.structure.BuiltinStructures;
import net.minecraft.world.level.levelgen.structure.Structure;
import com.mojang.datafixers.util.Pair;
import java.util.function.BiFunction;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** A "IA dentro do jogo": conversa, afinidade, obediencia e comportamentos. Roda na thread do servidor. */
public final class MobBrain {
    public static final int FRIEND = 10;   // segue / fica / nao ataca
    public static final int TRUSTED = 30;  // guarda o jogador
    public static final int LOYAL = 50;    // da presentes

    public enum Action { NONE, RELEASE, FOLLOW, STAY, GUARD, GIFT, FLEE, WANDER, LOOK }

    private record Reply(String say, Action action, String mood, int delta) {}

    private static final class Command {
        final Mob mob;
        final UUID playerId;
        final Action action;
        final int expiresAt;
        int nextWander;
        Command(Mob mob, UUID playerId, Action action, int expiresAt) {
            this.mob = mob; this.playerId = playerId; this.action = action; this.expiresAt = expiresAt;
        }
    }

    private static final Map<UUID, Command> COMMANDS = new HashMap<>();
    private static final Set<UUID> BUSY = new HashSet<>();
    private static final Map<UUID, Integer> LAST_THINK = new HashMap<>();
    private static final Map<UUID, Integer> GIFT_COOLDOWN = new HashMap<>();
    private static final Map<UUID, Integer> TALK_COOLDOWN = new HashMap<>();
    private static final Random RANDOM = new Random();
    private static final int SEARCH_RADIUS_CHUNKS = 48;

    private MobBrain() {}

    public static void clear() { COMMANDS.clear(); BUSY.clear(); LAST_THINK.clear(); GIFT_COOLDOWN.clear(); TALK_COOLDOWN.clear(); }
    public static void forget(UUID id) { COMMANDS.remove(id); BUSY.remove(id); LAST_THINK.remove(id); GIFT_COOLDOWN.remove(id); }

    private static int required(Action a) {
        return switch (a) {
            case FOLLOW, STAY -> FRIEND;
            case GUARD -> TRUSTED;
            case GIFT -> LOYAL;
            default -> -100;
        };
    }

    private static String label(int aff) {
        if (aff < -30) return "hostil";
        if (aff < 0) return "desconfiado";
        if (aff < FRIEND) return "conhecido";
        if (aff < TRUSTED) return "amigo";
        if (aff < LOYAL) return "muito confiável";
        return "melhor amigo, totalmente leal";
    }

    // ------------------------------------------------------------------ conversa
    public static void talk(MinecraftServer server, ServerPlayer player, Mob mob, String text) {
        if (text == null || text.isBlank()) return;

        // Anti-spam: evita que um jogador dispare dezenas de requisições pagas por segundo.
        int nowTick = server.getTickCount();
        Integer lastTalk = TALK_COOLDOWN.get(player.getUUID());
        if (lastTalk != null && nowTick - lastTalk < 10) return;
        TALK_COOLDOWN.put(player.getUUID(), nowTick);

        // Comerciantes oferecem orientação em troca da moeda correta.
        if (mob instanceof net.minecraft.world.entity.npc.Villager && asksForDirections(text)) {
            merchantDirections(player, mob, Items.EMERALD, 3, MobBrain::findVillage, "esmeraldas", "vila");
            return;
        }
        if (mob instanceof Piglin && asksForDirections(text)) {
            merchantDirections(player, mob, Items.GOLD_INGOT, 5, MobBrain::findBastion, "lingotes de ouro", "bastião piglin");
            return;
        }

        // Provocações/ofensas provocam criaturas capazes de lutar.
        if (isInsultOrChallenge(text) && (mob instanceof Monster || mob instanceof IronGolem)) {
            MobData provoked = MobMemoryState.get(server).getOrCreate(mob);
            provoked.addAffinity(player.getUUID(), -12);
            provoked.mood = "furioso";
            MobMemoryState.get(server).setDirty();
            mob.setTarget(player);
            mob.setLastHurtByMob(player);
            int provokedAff = provoked.getAffinity(player.getUUID());
            // Amigos (afinidade >= FRIEND) têm o alvo cancelado em ServerEvents.onChangeTarget.
            boolean aggressive = mob.getTarget() == player;
            Net.reply(player, mob,
                    aggressive ? "Você vai se arrepender de me provocar!" : "Isso doeu... mas ainda confio em você.",
                    provokedAff,
                    aggressive ? "Você provocou " + mob.getName().getString() + ". Ele ficou agressivo!"
                            : "Você ofendeu " + mob.getName().getString() + ", mas ele ainda é seu amigo e não atacou.");
            return;
        }

        AiConfig cfg = AiConfig.get();
        MobMemoryState state = MobMemoryState.get(server);
        MobData d = state.getOrCreate(mob);
        applyIdentity(mob, d, state);

        UUID id = mob.getUUID();
        if (AiClient.busy()) {
            Net.reply(player, mob, "...", d.getAffinity(player.getUUID()), "Muitas conversas em andamento. Tente de novo em instantes.");
            return;
        }
        if (!BUSY.add(id)) { // ja esta "pensando"
            Net.reply(player, mob, "...", d.getAffinity(player.getUUID()), d.name + " ainda está pensando.");
            return;
        }
        LAST_THINK.put(id, server.getTickCount());

        String userMsg = player.getName().getString() + " diz: " + text;
        List<AiClient.Msg> msgs = new ArrayList<>(d.history);
        msgs.add(new AiClient.Msg("user", userMsg));

        AiClient.chat(buildSystem(d, mob, player), msgs).whenComplete((raw, err) -> server.execute(() -> {
            BUSY.remove(id);
            if (err != null || raw == null) {
                MobVoice.LOGGER.warn("Falha na IA: {}", String.valueOf(err));
                Net.reply(player, mob, "...", d.getAffinity(player.getUUID()),
                        "A IA nao respondeu. Verifique a apiKey em config/mobvoice.json e o log.");
                return;
            }
            if (!mob.isAlive()) return;

            Reply r = parse(raw);
            int delta = Math.max(-5, Math.min(5, r.delta()));
            int aff = d.addAffinity(player.getUUID(), delta);
            if (!r.mood().isBlank()) d.mood = r.mood();

            String say = r.say().isBlank() ? "..." : r.say();
            d.addExchange(userMsg, say, cfg.historyLimit);
            state.setDirty();

            String note = execute(server, mob, d, player, r.action(), aff);
            Net.reply(player, mob, say, aff, note);
            maybeSummarize(server, state, d);
        }));
    }

    // ------------------------------------------------------------------ pensamento autonomo
    public static void tickBrain(MinecraftServer server) {
        AiConfig cfg = AiConfig.get();
        if (!cfg.autonomousBrain) return;
        MobMemoryState state = MobMemoryState.get(server);
        int now = server.getTickCount();

        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            List<Mob> mobs = p.serverLevel().getEntitiesOfClass(Mob.class,
                    p.getBoundingBox().inflate(10), m -> m.isAlive() && state.has(m.getUUID()));
            for (Mob m : mobs) {
                if (AiClient.busy()) return;
                UUID id = m.getUUID();
                if (BUSY.contains(id)) continue;
                Integer last = LAST_THINK.get(id);
                if (last != null && now - last < cfg.thinkIntervalSeconds * 20) continue;
                LAST_THINK.put(id, now);
                think(server, state, p, m);
            }
        }
    }

    private static void think(MinecraftServer server, MobMemoryState state, ServerPlayer p, Mob mob) {
        AiConfig cfg = AiConfig.get();
        MobData d = state.getOrCreate(mob);
        UUID id = mob.getUUID();
        BUSY.add(id);

        String obs = "[Observação do mundo] " + p.getName().getString() + " está a "
                + Math.round(mob.distanceTo(p)) + " blocos de você e não disse nada. "
                + "Decida por conta própria: quer falar algo espontaneamente (ou ficar em silêncio, com say vazio) "
                + "e que ação tomar? Use affinity_delta 0.";
        List<AiClient.Msg> msgs = new ArrayList<>(d.history);
        msgs.add(new AiClient.Msg("user", obs));

        AiClient.chat(buildSystem(d, mob, p), msgs).whenComplete((raw, err) -> server.execute(() -> {
            BUSY.remove(id);
            if (err != null || raw == null || !mob.isAlive()) return;
            Reply r = parse(raw);
            if (!r.mood().isBlank()) d.mood = r.mood();
            int aff = d.getAffinity(p.getUUID());
            String note = execute(server, mob, d, p, r.action(), aff);
            if (!r.say().isBlank()) {
                d.addRemark(r.say(), cfg.historyLimit);
                Net.reply(p, mob, r.say(), aff, note);
            }
            state.setDirty();
        }));
    }

    private static boolean asksForDirections(String text) {
        String t = text.toLowerCase(Locale.ROOT);
        return t.contains("onde fica") || t.contains("como chegar") || t.contains("me leve") ||
                t.contains("direção") || t.contains("direcao") || t.contains("caminho") ||
                t.contains("localizar") || t.contains("encontrar") || t.contains("onde encontro");
    }

    private static boolean isInsultOrChallenge(String text) {
        String t = text.toLowerCase(Locale.ROOT);
        String[] words = {"idiota", "imbecil", "covarde", "fracote", "fraco", "lixo", "inútil", "inutil", "te desafio", "vem lutar", "vamos lutar", "vou te matar", "quero briga", "seu monstro"};
        for (String w : words) if (t.contains(w)) return true;
        return false;
    }

    private static BlockPos findVillage(ServerLevel level, BlockPos origin) {
        // No 1.20.1 esta chamada devolve diretamente o BlockPos (ou null).
        return level.findNearestMapStructure(StructureTags.VILLAGE, origin, SEARCH_RADIUS_CHUNKS, false);
    }

    private static BlockPos findBastion(ServerLevel level, BlockPos origin) {
        // Não existe tag de estrutura para bastiões; consulta o gerador como o /locate faz.
        if (!level.getServer().getWorldData().worldGenSettings().generateStructures()) return null;
        Registry<Structure> registry = level.registryAccess().registryOrThrow(Registries.STRUCTURE);
        Optional<Holder.Reference<Structure>> holder = registry.getHolder(BuiltinStructures.BASTION_REMNANT);
        if (holder.isEmpty()) return null;
        Pair<BlockPos, Holder<Structure>> result = level.getChunkSource().getGenerator()
                .findNearestMapStructure(level, HolderSet.direct(holder.get()), origin, SEARCH_RADIUS_CHUNKS, false);
        return result == null ? null : result.getFirst();
    }

    private static void merchantDirections(ServerPlayer player, Mob merchant,
                                           net.minecraft.world.item.Item item, int price,
                                           BiFunction<ServerLevel, BlockPos, BlockPos> finder,
                                           String currency, String destination) {
        int count = player.getInventory().countItem(item);
        if (count < price) {
            Net.reply(player, merchant, "Posso ajudar, mas meu preço é " + price + " " + currency + ".", 0,
                    "Você precisa de " + price + " " + currency + " para receber a orientação.");
            return;
        }
        BlockPos pos = finder.apply(player.serverLevel(), player.blockPosition());
        if (pos == null) {
            Net.reply(player, merchant, "Não conheço nenhum " + destination + " por perto.", 0,
                    "Nenhum destino desse tipo foi localizado em até " + SEARCH_RADIUS_CHUNKS + " chunks.");
            return;
        }
        // Inventory não tem removeItem(Item, int); usa o mesmo mecanismo do /clear.
        player.getInventory().clearOrCountMatchingItems(st -> st.is(item), price, player.inventoryMenu.getCraftSlots());
        player.containerMenu.broadcastChanges();
        player.inventoryMenu.slotsChanged(player.getInventory());

        double dx = pos.getX() - player.getX();
        double dz = pos.getZ() - player.getZ();
        String direction = directionName(dx, dz);
        String answer = "O " + destination + " mais próximo fica aproximadamente em X=" + pos.getX() + ", Z=" + pos.getZ() + ". Siga para " + direction + ".";
        Net.reply(player, merchant, answer, 0, "Pagamento recebido: " + price + " " + currency + ".");
    }

    private static String directionName(double dx, double dz) {
        String ns = dz < -20 ? "norte" : dz > 20 ? "sul" : "";
        String ew = dx > 20 ? "leste" : dx < -20 ? "oeste" : "";
        if (ns.isEmpty()) return ew.isEmpty() ? "em frente" : ew;
        if (ew.isEmpty()) return ns;
        return ns + " e " + ew;
    }

    // ------------------------------------------------------------------ prompt
    private static String buildSystem(MobData d, Mob mob, ServerPlayer p) {
        int aff = d.getAffinity(p.getUUID());
        String held = p.getMainHandItem().isEmpty() ? "nada" : p.getMainHandItem().getHoverName().getString();
        String weaponReaction = p.getMainHandItem().isEmpty() ? "mãos vazias" :
                p.getMainHandItem().is(Items.BOW) || p.getMainHandItem().is(Items.CROSSBOW) ? "arco/besta" :
                p.getMainHandItem().is(Items.IRON_SWORD) || p.getMainHandItem().is(Items.DIAMOND_SWORD) || p.getMainHandItem().is(Items.NETHERITE_SWORD) || p.getMainHandItem().is(Items.WOODEN_SWORD) || p.getMainHandItem().is(Items.STONE_SWORD) || p.getMainHandItem().is(Items.GOLDEN_SWORD) ? "espada" :
                p.getMainHandItem().getItem() instanceof net.minecraft.world.item.AxeItem ? "machado" : "outro item";
        StringBuilder s = new StringBuilder();
        s.append("Você é ").append(d.name).append(", um(a) ").append(d.type).append(" de Minecraft com vida própria.\n");
        s.append("Personalidade: ").append(d.personality).append(".\n");
        s.append("História: ").append(d.backstory).append("\n");
        s.append("Humor atual: ").append(d.mood).append(".\n");
        if (!d.summary.isBlank()) s.append("O que você lembra de conversas antigas: ").append(d.summary).append("\n");
        s.append("Situação agora: ").append(mob.level().isDay() ? "é de dia" : "é de noite")
                .append("; sua vida é ").append(Math.round(mob.getHealth())).append("/").append(Math.round(mob.getMaxHealth()))
                .append("; ").append(p.getName().getString()).append(" está a ")
                .append(Math.round(mob.distanceTo(p))).append(" blocos, segurando ").append(held)
                .append(" (categoria: ").append(weaponReaction).append(").\n");
        s.append("REAÇÃO A EQUIPAMENTOS: reaja de forma coerente ao item na mão do jogador. Espadas e machados podem intimidar criaturas pacíficas; arcos e bestas deixam criaturas cautelosas ou assustadas. Criaturas agressivas podem ameaçar ou atacar se forem provocadas.\n");
        s.append("PROVOCAÇÕES: insultos, ameaças e desafios diretos podem reduzir muito sua confiança e fazer criaturas de combate atacarem o jogador.\n");
        s.append("Sua afinidade com ").append(p.getName().getString()).append(" é ").append(aff)
                .append(" (de -100 a 100): ").append(label(aff)).append(".\n\n");

        s.append("OBEDIÊNCIA: quem conversa bem com você ganha sua confiança. ")
                .append("Você só aceita FOLLOW ou STAY com afinidade >= ").append(FRIEND)
                .append("; GUARD (proteger o jogador de monstros) com afinidade >= ").append(TRUSTED)
                .append("; GIFT (dar um presente) com afinidade >= ").append(LOYAL).append(". ")
                .append("Se o pedido for permitido pela afinidade, você OBEDECE de bom grado (pode resmungar em personagem, mas faz). ")
                .append("Se a afinidade for insuficiente, recuse em personagem e deixe claro que precisa conhecer melhor o jogador ")
                .append("(conversar mais, ser gentil). RELEASE = o jogador te libera do pedido anterior.\n");
        s.append("AFINIDADE: em affinity_delta, dê +1 a +5 se a conversa foi agradável, sincera, engraçada ou mostrou interesse ")
                .append("genuíno por você e sua história; 0 se foi neutra; -1 a -5 se foi rude, repetitiva (spam), ")
                .append("insistente ou ameaçadora. Elogios vazios e repetidos valem no máximo +1.\n\n");

        s.append("Regras: fale sempre como o personagem, em português do Brasil, em no máximo 2 frases curtas. ")
                .append("Nunca saia do personagem nem diga que é uma IA. Lembre do que já foi dito.\n");
        s.append("Responda SOMENTE com JSON, sem texto fora dele: ")
                .append("{\"say\":\"sua fala\",\"action\":\"NONE|RELEASE|FOLLOW|STAY|GUARD|GIFT|FLEE|WANDER|LOOK\",")
                .append("\"mood\":\"uma palavra\",\"affinity_delta\":0}\n");
        s.append("FOLLOW = seguir; STAY = ficar parado; GUARD = seguir e proteger; GIFT = dar um presentinho; ")
                .append("FLEE = fugir assustado; WANDER = passear; LOOK = olhar para o jogador; NONE = nada novo.");
        return s.toString();
    }

    private static Reply parse(String raw) {
        String s = raw.trim();
        int a = s.indexOf('{'), b = s.lastIndexOf('}');
        if (a >= 0 && b > a) {
            try {
                JsonObject o = JsonParser.parseString(s.substring(a, b + 1)).getAsJsonObject();
                Action act = Action.NONE;
                try { act = Action.valueOf(str(o, "action").trim().toUpperCase(Locale.ROOT)); } catch (Exception ignored) {}
                int delta = 0;
                try { delta = o.has("affinity_delta") ? o.get("affinity_delta").getAsInt() : 0; } catch (Exception ignored) {}
                return new Reply(cap(str(o, "say"), 400), act, cap(str(o, "mood"), 32), delta);
            } catch (Exception ignored) {}
        }
        return new Reply(cap(s, 400), Action.NONE, "", 0);
    }

    private static String cap(String v, int max) {
        if (v == null) return "";
        v = v.trim();
        return v.length() <= max ? v : v.substring(0, max - 1) + "…";
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }

    // ------------------------------------------------------------------ memoria de longo prazo
    private static void maybeSummarize(MinecraftServer server, MobMemoryState state, MobData d) {
        int limit = AiConfig.get().historyLimit;
        if (d.history.size() <= limit || d.summarizing || AiClient.busy()) return;

        int n = Math.max(2, (d.history.size() / 2) & ~1);
        StringBuilder sb = new StringBuilder();
        if (!d.summary.isBlank()) sb.append("Resumo anterior: ").append(d.summary).append("\n\n");
        sb.append("Conversas a resumir:\n");
        for (int i = 0; i < n; i++) {
            AiClient.Msg m = d.history.get(i);
            sb.append(m.role().equals("assistant") ? d.name + ": " : "").append(m.content()).append("\n");
        }
        d.summarizing = true;
        String sys = "Você guarda as memórias do personagem " + d.name + ". Resuma em até 5 frases, em português, "
                + "na primeira pessoa, os fatos importantes: nomes, promessas, gostos dos jogadores e sentimentos. "
                + "Responda só com o resumo.";
        AiClient.chat(sys, List.of(new AiClient.Msg("user", sb.toString()))).whenComplete((res, err) -> server.execute(() -> {
            d.summarizing = false;
            if (err != null || res == null || res.isBlank()) return;
            d.summary = res.trim();
            for (int i = 0; i < n && !d.history.isEmpty(); i++) d.history.remove(0);
            while (!d.history.isEmpty() && d.history.get(0).role().equals("assistant")) d.history.remove(0);
            state.setDirty();
        }));
    }

    // ------------------------------------------------------------------ acoes
    private static void applyIdentity(Mob mob, MobData d, MobMemoryState state) {
        Component current = mob.getCustomName();
        if (current != null && !current.getString().isBlank()) {
            // Respeita nome dado pelo jogador (name tag): o mob passa a se chamar assim.
            String custom = cap(current.getString(), 40);
            if (!custom.equals(d.name)) { d.name = custom; state.setDirty(); }
        } else {
            mob.setCustomName(Component.literal(d.name));
            mob.setCustomNameVisible(true);
        }
        mob.setPersistenceRequired(); // nao some por despawn
    }

    /** Aplica a acao respeitando a afinidade. Devolve uma nota para o jogador (ou ""). */
    private static String execute(MinecraftServer server, Mob mob, MobData d, ServerPlayer p, Action a, int aff) {
        if (a == Action.NONE) return "";
        int need = required(a);
        if (aff < need) {
            return d.name + " ainda não confia o bastante em você (afinidade " + aff + "/" + need + "). Converse mais!";
        }
        switch (a) {
            case RELEASE -> COMMANDS.remove(mob.getUUID());
            case GIFT -> { return gift(server, mob, d); }
            default -> {
                int ticks = (a == Action.FOLLOW || a == Action.STAY || a == Action.GUARD) ? 20 * 60 * 10 : 20 * 60;
                COMMANDS.put(mob.getUUID(), new Command(mob, p.getUUID(), a, server.getTickCount() + ticks));
            }
        }
        return "";
    }

    private static String gift(MinecraftServer server, Mob mob, MobData d) {
        int now = server.getTickCount();
        Integer last = GIFT_COOLDOWN.get(mob.getUUID());
        if (last != null && now - last < 20 * 60 * 5) return d.name + " já deu um presente há pouco.";
        GIFT_COOLDOWN.put(mob.getUUID(), now);
        int r = RANDOM.nextInt(100);
        ItemStack stack;
        if (r < 30) stack = new ItemStack(Items.BREAD, 2);
        else if (r < 55) stack = new ItemStack(Items.APPLE, 2);
        else if (r < 70) stack = new ItemStack(Items.COOKIE, 4);
        else if (r < 83) stack = new ItemStack(Items.IRON_NUGGET, 3);
        else if (r < 92) stack = new ItemStack(Items.GOLD_NUGGET, 2);
        else if (r < 98) stack = new ItemStack(Items.POPPY, 1);
        else stack = new ItemStack(Items.EMERALD, 1);
        mob.spawnAtLocation(stack);
        return "";
    }

    private static boolean canFight(Mob mob) {
        return mob instanceof Monster || mob instanceof IronGolem;
    }

    /** Reaplica o comportamento escolhido. Chamar a cada ~5 ticks. */
    public static void tickCommands(MinecraftServer server) {
        if (COMMANDS.isEmpty()) return;
        MobMemoryState state = MobMemoryState.get(server);
        int now = server.getTickCount();
        Iterator<Command> it = COMMANDS.values().iterator();
        while (it.hasNext()) {
            Command c = it.next();
            Mob mob = c.mob;
            ServerPlayer p = server.getPlayerList().getPlayer(c.playerId);
            if (mob.isRemoved() || !mob.isAlive() || p == null || now > c.expiresAt || mob.level() != p.level()) {
                it.remove();
                continue;
            }
            if (mob.getTarget() == p) mob.setTarget(null); // nunca ataca quem esta conversando com ele
            double dist = mob.distanceTo(p);

            switch (c.action) {
                case FOLLOW -> {
                    if (dist > 3) mob.getNavigation().moveTo(p, 1.1);
                    else mob.getNavigation().stop();
                    mob.getLookControl().setLookAt(p, 30f, 30f);
                }
                case STAY -> {
                    mob.getNavigation().stop();
                    mob.getLookControl().setLookAt(p, 30f, 30f);
                }
                case LOOK -> mob.getLookControl().setLookAt(p, 30f, 30f);
                case GUARD -> {
                    if (canFight(mob) && (mob.getTarget() == null || !mob.getTarget().isAlive())) {
                        Monster foe = p.serverLevel().getEntitiesOfClass(Monster.class, p.getBoundingBox().inflate(14),
                                        m -> m != mob && m.isAlive() && !state.has(m.getUUID()))
                                .stream().min(Comparator.comparingDouble(m -> m.distanceToSqr(p))).orElse(null);
                        if (foe != null) mob.setTarget(foe);
                    }
                    if (mob.getTarget() == null) {
                        if (dist > 4) mob.getNavigation().moveTo(p, 1.2);
                        else mob.getNavigation().stop();
                    } else if (dist > 16) {
                        mob.setTarget(null);
                        mob.getNavigation().moveTo(p, 1.3);
                    }
                }
                case FLEE -> {
                    if (dist > 16) { it.remove(); continue; }
                    Vec3 away = mob.position().subtract(p.position()).normalize().scale(10);
                    mob.getNavigation().moveTo(mob.getX() + away.x, mob.getY(), mob.getZ() + away.z, 1.4);
                }
                case WANDER -> {
                    if (now >= c.nextWander) {
                        mob.getNavigation().moveTo(mob.getX() + RANDOM.nextInt(13) - 6,
                                mob.getY(), mob.getZ() + RANDOM.nextInt(13) - 6, 1.0);
                        c.nextWander = now + 60;
                    }
                }
                default -> {}
            }
        }
    }
}
