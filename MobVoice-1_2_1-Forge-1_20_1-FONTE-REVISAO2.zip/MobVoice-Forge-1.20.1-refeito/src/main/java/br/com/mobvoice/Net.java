package br.com.mobvoice;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MobVoice.MOD_ID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private Net() {}

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, TalkPacket.class, TalkPacket::encode, TalkPacket::decode, TalkPacket::handle);
        CHANNEL.registerMessage(id++, ReplyPacket.class, ReplyPacket::encode, ReplyPacket::decode, ReplyPacket::handle);
    }

    public static void reply(ServerPlayer player, Mob mob, String text, int affinity, String note) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new ReplyPacket(mob.getId(), clip(text, 1024), affinity, clip(note, 256)));
    }

    /** writeUtf lança exceção se a string passar do limite; garante que o pacote sempre pode ser escrito. */
    static String clip(String value, int max) {
        if (value == null) return "";
        return value.length() <= max ? value : value.substring(0, max);
    }
}
