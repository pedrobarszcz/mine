#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then
  echo "Java não encontrado. Instale o JDK 17."; exit 1
fi
JAVA_VERSION=$(java -version 2>&1 | head -n 1)
echo "$JAVA_VERSION"
if ! [[ "$JAVA_VERSION" =~ version\ \"17[.\"] ]]; then
  echo "Este projeto exige JDK 17."; exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle não encontrado. Instale o Gradle 8.1.1 (ForgeGradle 6.0 não funciona com Gradle 9) e tente novamente."; exit 1
fi
GRADLE_MAJOR=$(gradle --version 2>/dev/null | awk '/^Gradle /{split($2,v,"."); print v[1]; exit}')
if [[ "${GRADLE_MAJOR:-0}" != "8" ]]; then
  echo "Este projeto exige Gradle 8.x (recomendado 8.1.1). Versão encontrada: ${GRADLE_MAJOR:-desconhecida}."; exit 1
fi
gradle --no-daemon clean build
echo "JAR gerado em build/libs/"
